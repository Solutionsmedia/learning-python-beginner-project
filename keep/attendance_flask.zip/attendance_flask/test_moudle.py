from database import Database
from errors import AttendanceError, DatabaseError
DATABASE_FILE = "attendance_flask/attendance.json"
db = Database(DATABASE_FILE)


# Testing Reading
data = db.read_db()
print(data)


# Testing Appending and writing
data = {"name"}
try:
    if db.append(data):
        print("Successfully Write DB")
except Exception as e:
    raise AttendanceError(
        f"An error occured while processing your request: {e}")
