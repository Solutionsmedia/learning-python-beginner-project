class DatabaseError:
    pass


class AttendanceError:
    pass
