import json
import os
from errors import DatabaseError
from validators import Validate
# Database Strucure
# {
#     "student_name": "John Doe",
#     "date": "2026-01-05",
#     "status": "present"
# }


class Database:
    def __init__(self, filename):
        self.filename = filename
        self._check_db_status()

    def _check_db_status(self):
        if not os.path.exists(self.filename):
            data = []
            with open(self.filename, "w") as f:
                json.dump(data, f)
        else:
            return True

    def read_db(self):
        with open(self.filename, "r") as f:
            data = json.load(f)
            return data

    def append(self, data):
        try:
            if Validate.validate(data):
                db = self.read_db()
                db.append(data)
                self.write_db(db)
                return True
        except Exception as e:
            raise DatabaseError(
                "System level error occured while appending and writing the information, system says {e}")

    def write_db(self, data):
        try:
            with open(self.filename, 'w'):
                json.dump(data, self.filename)
        except Exception as e:
            raise DatabaseError(
                f"A system Level Error Occured while writing the databse, system says {e}")
